from turtle import Turtle

class Ball(Turtle):
    
    def __init__(self):
        super().__init__()
        self.color("white")
        self.shape("circle")
        self.penup()
        self.x_move = 10
        self.y_move = 10
        self.ball_speed = 0.1
        
    def move(self):
        new_x = self.xcor() + self.x_move	#increasing amount of the ball movement
        new_y = self.ycor() + self.y_move
        self.goto(0,0)
        self.goto(new_x,new_y)
        
        
    def bounce_y(self):
        #To bounde along the y axis (top and bottom walls)
        #we need to change the y_move to make it the opposite to change direction
        self.y_move *= -1 #multiply by - 1 to get the opposite number, therefore reversing the direction of the ball

    def bounce_x(self):
        # To bounce along the x axis, that is, agianst the paddle
        self.x_move *= -1
        self.ball_speed *= 0.9
        
        
    def reset_position(self):#should move towards the winning player, that is we inverse the X
        self.goto(0,0)
        self.ball_speed = 0.1
        self.bounce_x()
        
    