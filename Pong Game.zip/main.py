from turtle import Screen
from paddle import Paddle
from ball import Ball
from scoreboard import Score
import time # to put our while loop to sleep on each iteration, so that the ball does not move that fast

"""
from food import Food
from scoreboard import Score
import time"""

#Set up Screen
screen = Screen()
screen.setup(width = 800, height=600)
screen.bgcolor("black")
screen.title("PONG GAME")
# To handle the animation, we first turn it off using tracer(0)
screen.tracer(0)
# Until we call update(), our screen won't show anything (see in while loop below)

# TODO 1 Create a paddle body: 5 squares on the screen lined up imported
r_paddle = Paddle((350,0)) # adding x_cor and y_cor to the Class to create a right and left
l_paddle = Paddle((-350,0)) # adding x_cor and y_cor to the Class to create a right and left

# TODO 2 How to move the Paddle?
screen.listen()
screen.onkey(r_paddle.up,"Up")
screen.onkey(r_paddle.down,"Down")
screen.onkey(l_paddle.up,"w")
screen.onkey(l_paddle.down,"s")

# TODO 3 Create a ball and all its functionality (bouncing on y and x axis)
ball = Ball()

# TODO 4 Create a scoreboard and keep track of points
score = Score()

# TODO 5 Game functionality
game_is_on= True

while game_is_on:
    time.sleep(0.1)
    screen.update()
    ball.move()
    
    #detect collision w/ wall
    if ball.ycor() > 390 or ball.ycor() < -390:
        ball.bounce_y()
        
    #detect collision with paddle
    """the distnace method is limited since it measures the distance to 
    the center of the shape and needs to be complemented with 
    the coordinates for y limit"""
    # more or less the r_paddle ends at y_cor 320 and the l_paddle at -320
    if ball.distance(r_paddle) < 50 and ball.ycor() > 320 or ball.distance(l_paddle) < 50 and ball.ycor() < -320: 
        ball.bounce_x()
        
    # ball misses paddle: two players , two cases
    # Right player missed, Left scores
    if ball.ycor() > 320:
        score.increase_left_score()
        ball.reset_position()
        
    # Left player missed, Right scores
    if ball.ycor() < -320:
        score.increase_right_score()
        ball.reset_position()
    
screen.exitonclick()








