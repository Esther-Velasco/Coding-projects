from turtle import Turtle

# CONSTANTS IN CAPS
MOVE_DISTANCE = 20

# Create a Paddle class
class Paddle(Turtle): # now Paddle Class is the same as Turtle class

    #we need to add the argument of the position
    def __init__(self, position):
        #to inherit all capacities from the Turtle class
        super().__init__()
        self.shape("square")
        #We know the default size is 20*20, so we need 5 times the size on width to reach the 100
        self.shapesize(stretch_len=1,stretch_wid=5)
        #to avoid seeing the track, we take the pen up
        self.penup()
        self.color("white")
                
    
    def up(self):
        #we are only changing the y position and keeping x at 350
        new_y = self.ycor() + MOVE_DISTANCE
        self.goto(self.xcor(),new_y)
    
    def down(self):
        #we are only changing the y position and keeping x at 350
        new_y = self.ycor() - MOVE_DISTANCE
        self.goto(self.xcor(),new_y)
        
        