from turtle import Turtle

ALLIGNMENT = "center"
FONT = ("Arial",24,"bold")

class Score(Turtle):
    def __init__(self):
        #adopting all qualities from the turtle class
        super().__init__()
        self.score_player_right = 0
        self.score_player_left = 0
        self.color("white")
        self.penup()
        self.hideturtle()
        self.refresh()
        self.update_scoreboard()
        
    def update_scoreboard(self):    
        self.clear()
        self.goto(x=-100,y=200)
        self.write(self.score_player_left ,align= ALLIGNMENT, font = FONT)
        self.goto(x=100,y=200)
        self.write(self.score_player_right ,align= ALLIGNMENT, font = FONT)
        
    def increase_right_score(self):
        self.score_player_right += 1
        self.update_scoreboard()
        
    def increase_left_score(self):
        self.score_player_left += 1
        self.update_scoreboard()

    def game_over(self):
        self.goto(x=0,y=0)
        self.write("Game Over",align= ALLIGNMENT, font = FONT)
