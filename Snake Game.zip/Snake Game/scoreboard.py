from turtle import Turtle

ALLIGNMENT = "center"
FONT = ("Arial",24,"bold")

class Score(Turtle):
    def __init__(self):
        super().__init__()
        self.score = 0
        self.color("white")
        self.penup()
        self.goto(x=0,y=270)
        self.hideturtle()
        self.refresh()
        
    def refresh(self):
        self.write(f"Score: {self.score}",align= ALLIGNMENT, font = FONT)
        
    def increase_score(self):
        self.score += 1
        self.clear()
        self.refresh()

    def game_over(self):
        self.goto(x=0,y=0)
        self.write("Game Over",align= ALLIGNMENT, font = FONT)
        
        