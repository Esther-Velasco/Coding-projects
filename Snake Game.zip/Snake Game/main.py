from turtle import Screen
from snake import Snake
from food import Food
from scoreboard import Score
import time

screen = Screen()
screen.setup(width = 600, height=600)
screen.bgcolor("black")
screen.title("My Snake Game")
# To handle the animation:
screen.tracer(0)
# Until we call update(), our creen won't show anything

# TODO 1 Create a snake body: three squares on the screen lined up imported
snake = Snake() # calling create snake from the Snake() class
food = Food()
score = Score()

# TODO 2 How to move the snake? Keep moving forward automatically and continously
screen.listen()
screen.onkey(snake.up,"Up")
screen.onkey(snake.down,"Down")
screen.onkey(snake.left,"Left")
screen.onkey(snake.right,"Right")

'''
Since we want something to continiously happen unless something specific 
occurs we use a "while loop". For this we need a variable to keep track of the
game status
'''

game_on = True

while game_on:
    #we will move each of the segments
    #looping through our list of segments, and make each go forward
    screen.update()
    time.sleep(0.2) #delay for one second each loop
    snake.move()
    
    #Detect collision with food
    if snake.head.distance(food) < 15: # (circle diameter is 10)
        food.refresh()
        score.increase_score()
    #Detect collision with wall
    if snake.head.xcor() < 280 or snake.head.xcor(-280) or snake.head.ycor(-280) or snake.head.ycor(280):
        game_on = False
        score.game_over()
    
    #Detect collision with tail
    for segment in snake.snake_length[1:]: #using Slicing
        if snake.head.distance(segment)<10:
            game_on = False
            score.game_over()
            
screen.exitonclick()

