from turtle import Turtle

#CONSTANTS ARE ALWAYS UPPERCASE
START_LIST = [(0,0),(-20,0),(-40,0)]
MOVE_DISTANCE = 20
UP = 90
DOWN = 270
LEFT = 180
RIGHT = 0

# TODO 1 Create the Snake() class
class Snake:
    def __init__(self):
       
        # To keep record of created snakes(squares)
        self.snake_length = []
        self.create_snake()
        self.head = self.snake_length[0]
    
        
    def create_snake(self):
        for position in START_LIST:
            self.add_segment(position)
            
    def add_segment(self,position):
            snake = Turtle(shape = "square")
            #to avoid seeing the track, we take the pen up
            snake.penup()
            snake.color("white")
            snake.goto(position)
            self.snake_length.append(snake)
            
    def extend(self):
        self.add_segment(self.snake_length[-1].position())

    # TODO 2 Create the move() method of the Snake() class
    '''
    we start from the last segment, moving it to the second last seg position 
    and we move the second last segment to the position of the first seg and the 
    head goes forward
    '''

    def move(self):
        for segment_numb in range(len(self.snake_length)-1,0,-1):
            new_x = self.snake_length[segment_numb-1].xcor()
            new_y = self.snake_length[segment_numb-1].ycor()
            self.snake_length[segment_numb].goto(new_x,new_y)
            #once all segments have changed their position we move forward
        self.head.forward(MOVE_DISTANCE)
        
    def up(self):
        if self.head.heading() != DOWN:  
            self.head.setheading(UP)
    
    def down(self):
        if self.head.heading() != UP:  
            self.head.setheading(DOWN)
        
    def left(self):
        if self.head.heading() != RIGHT:  
            self.head.setheading(LEFT)

    def right(self):
        if self.head.heading() != LEFT:  
            self.head.setheading(RIGHT)
        
