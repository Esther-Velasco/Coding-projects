from turtle import Turtle
import random
#Introduction to the concept of class inheritance

# We want our Food class to inherit all attributes and methods from Turtle class
# But to also have some other behaviours that we manually set
class Food(Turtle):
    # We need to call the Turtle init method inside the Food init method
    
    """ All that i code inside the init function will be triggered whenever I
    call the Food class"""
    
    def __init__(self):
        super().__init__()
        # I am going to use a method for Turtle class, and modify it
        self.shape("circle")
        self.penup()
        self.shapesize(stretch_len=0.5,stretch_wid=0.5)
        self.color("green")
        self.speed("fastest")
        self.refresh()
        
        
    def refresh(self):
        random_x = random.randint(-280, 280)
        random_y = random.randint(-280, 280)
        self.goto(random_x,random_y)
        

